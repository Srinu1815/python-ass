$scope.validateCustom = function() {
    return $scope.user.name && $scope.user.name.length > 3; // Custom validation
};


if ($scope.myForm.$valid && $scope.validateCustom()) {
    alert('Form submitted successfully!');
}
