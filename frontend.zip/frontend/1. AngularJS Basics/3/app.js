// app.js
var app = angular.module('myApp', []);

// Controller definition
app.controller('MainController', ['$scope', function($scope) {
    $scope.init = function() {
        $scope.userName = '';
        $scope.names = ['Alice', 'Bob', 'Charlie'];
    };
}]);
