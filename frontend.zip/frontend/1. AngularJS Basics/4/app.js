// app.js
var app = angular.module('myApp', []);

// Main Controller
app.controller('MainController', ['$scope', '$rootScope', function($scope, $rootScope) {
    // Local scope variable
    $scope.localMessage = 'Hello from MainController!';
    
    // Global scope variable
    $rootScope.globalMessage = 'This is a global message!';
}]);

// Another Controller
app.controller('AnotherController', ['$scope', function($scope) {
    // The globalMessage can be accessed and modified here
}]);
