// directive.js
app.directive('myDirective', function() {
    return {
        restrict: 'E',
        scope: {
            message: '='
        },
        template: '<div>Your message is: <strong>{{ message }}</strong></div>'
    };
});
