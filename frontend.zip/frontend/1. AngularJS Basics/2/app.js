// app.js
var app = angular.module('myApp', []);

// Controller definition
app.controller('MyController', ['$scope', function($scope) {
    $scope.title = 'AngularJS Directive Example';
    $scope.message = '';
}]);
