function calculateArea(radius) {
    console.log('Calculating area for radius:', radius); // Debugging statement
    if (radius < 0) {
        console.error('Radius cannot be negative');
        return null;
    }
    const area = Math.PI * radius * radius;
    console.log('Calculated area:', area); // Debugging statement
    return area;
}

calculateArea(5);
calculateArea(-3); // This will show an error in the console
